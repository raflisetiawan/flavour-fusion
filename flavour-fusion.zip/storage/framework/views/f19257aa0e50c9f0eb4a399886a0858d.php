<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4">Orders for Menu: <?php echo e($menu->name); ?></h1>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Orders List
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Order Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->order->customer->name); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->subtotal); ?></td>
                        <td><?php echo e($order->order->order_date); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="<?php echo e(route('pemilikKedai.menu.index')); ?>" class="btn btn-secondary">Back to Menu List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kedai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\PemrogramanWeb\flavour-fusion\resources\views/pages/kedai/menu/orders.blade.php ENDPATH**/ ?>
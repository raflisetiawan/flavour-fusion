<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manage Pengajuan Pemilik Kedai</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Manage Pengajuan Pemilik Kedai</li>
    </ol>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Daftar Pengajuan Kedai
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Nama Kedai</th>
                        <th>Deskripsi</th>
                        <th>Gambar</th>
                        <th>Pengaju</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pengajuanKedai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kedai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($kedai->name); ?></td>
                            <td><?php echo e($kedai->description); ?></td>
                            <td>
                                <?php if($kedai->image): ?>
                                    <img src="<?php echo e(asset('storage/'.$kedai->image)); ?>" alt="<?php echo e($kedai->name); ?>" width="100">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($kedai->user->name); ?></td>
                            <td>
                                <form action="<?php echo e(route('admin.manage-pengajuan-pemilik-kedai.approve', $kedai->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-success">Approve</button>
                                </form>
                                <form action="<?php echo e(route('admin.manage-pengajuan-pemilik-kedai.reject', $kedai->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-danger">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\PemrogramanWeb\flavour-fusion\resources\views/pages/admin/manage-pengajuan-pemilik-kedai.blade.php ENDPATH**/ ?>
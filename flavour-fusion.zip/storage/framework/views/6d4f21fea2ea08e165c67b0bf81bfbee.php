<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($kedai->name); ?></h1>
    

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-2">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kedai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\PemrogramanWeb\flavour-fusion\resources\views/pages/pemilik-kedai/index.blade.php ENDPATH**/ ?>
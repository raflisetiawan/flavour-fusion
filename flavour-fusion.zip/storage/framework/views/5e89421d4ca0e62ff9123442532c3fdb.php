<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Manage Kedai</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Kedai</li>
        </ol>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-store me-1"></i>
                Kedai List
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kedai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($k->name); ?></td>
                                <td><?php echo e($k->description); ?></td>
                                <td><img src="<?php echo e(asset('storage/' . $k->image)); ?>" alt="<?php echo e($k->name); ?>" width="100"></td>
                                <td>
                                    <a href="<?php echo e(route('admin.kedai.edit', $k->id)); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(route('admin.kedai.destroy', $k->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\PemrogramanWeb\flavour-fusion\resources\views/pages/admin/kedai/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4">Manage Menu</h1>
    <a href="<?php echo e(route('pemilikKedai.menu.create')); ?>" class="btn btn-primary mb-3">Create New Menu</a>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Menu List
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($menu->name); ?></td>
                        <td><?php echo e($menu->description); ?></td>
                        <td><?php echo e($menu->price); ?></td>
                        <td>
                            <?php if($menu->image): ?>
                            <img src="<?php echo e(asset('storage/' . $menu->image)); ?>" alt="<?php echo e($menu->name); ?>" width="50">
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('pemilikKedai.menu.edit', $menu->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('pemilikKedai.menu.destroy', $menu->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                            <a href="<?php echo e(route('pemilikKedai.menu.showOrderDetails', $menu->id)); ?>" class="btn btn-info btn-sm">View Orders</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kedai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\PemrogramanWeb\flavour-fusion\resources\views/pages/kedai/menu/index.blade.php ENDPATH**/ ?>